// Service worker: orchestrates tab-audio capture → offscreen Soniox stream → content overlay.

// source: "tab" (tab audio) | "tabmic" (tab + your mic) | "mic" (microphone only, in-person)
let active = { tabId: null, running: false, lang: "ko", langB: "vi", way: "one", source: "tab", panel: false };

// A dedicated subtitle window (panel.html) so translation works even when the
// current tab can't host the overlay (chrome://, new-tab, blank) or the user
// wants it always-on without opening any web page (e.g. in-person via mic).
let panelWindowId = null;
async function openPanel() {
  if (panelWindowId != null) {
    try { await chrome.windows.update(panelWindowId, { focused: true }); return; } catch { panelWindowId = null; }
  }
  const w = await chrome.windows.create({ url: chrome.runtime.getURL("panel.html"), type: "popup", width: 470, height: 580, focused: true });
  panelWindowId = w && w.id != null ? w.id : null;
}
chrome.windows.onRemoved.addListener((wid) => {
  // Closing the panel window ends the session so audio streaming (and cost) stops.
  if (wid === panelWindowId) { panelWindowId = null; if (active.running) endCapture(false); }
});

async function hasOffscreen() {
  const ctxs = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  return ctxs.length > 0;
}

async function ensureOffscreen() {
  if (await hasOffscreen()) return;
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA"],
    justification: "Capture tab audio and stream it for real-time translation.",
  });
}

// Recreate a fresh offscreen document so it picks up the current mic permission
// (an offscreen created before the grant stays denied = NotAllowedError).
async function recreateOffscreen() {
  try { if (await hasOffscreen()) await chrome.offscreen.closeDocument(); } catch {}
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA"],
    justification: "Capture tab audio and stream it for real-time translation.",
  });
}

// Transcribe-only ("Chỉ ghi") is free of translation cost, so it doesn't count
// against the paid quota — but it's capped at 60 min/day per device to bound the
// STT cost. Usage is tracked in chrome.storage.local (persistent across sessions).
const TR_DAILY = 3600;
function trToday() { return new Date().toISOString().slice(0, 10); }
async function trRemain() {
  const s = await chrome.storage.local.get(["tr_day", "tr_used"]);
  const used = s.tr_day === trToday() ? (s.tr_used || 0) : 0;
  return Math.max(0, TR_DAILY - used);
}
async function trAdd(sec) {
  const s = await chrome.storage.local.get(["tr_day", "tr_used"]);
  const used = (s.tr_day === trToday() ? (s.tr_used || 0) : 0) + (sec || 0);
  await chrome.storage.local.set({ tr_day: trToday(), tr_used: used });
  return used >= TR_DAILY;
}

async function startCapture(lang, resume, sourcev, wayv, langBv, tabIdArg, panelArg) {
  const source = (resume ? active.source : sourcev) || "tab";
  // Use the tab the popup captured (so a mic-permission tab can't hijack "active").
  let tabId = resume ? active.tabId : tabIdArg;
  if (!tabId) { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); tabId = t && t.id; }
  // Tab/Tab+mic need a real tab to capture; Mic (in-person) doesn't.
  if (!tabId && source !== "mic") throw new Error("Không tìm thấy tab");

  // Enforce the 60-min/day cap for transcribe-only before starting.
  const effWay = resume ? active.way : wayv;
  if (effWay === "off" && (await trRemain()) <= 0) {
    throw new Error("Đã dùng hết 60 phút Chỉ ghi hôm nay. Quay lại ngày mai, hoặc dùng chế độ dịch.");
  }

  let usePanel = resume ? active.panel : !!panelArg;
  if (resume) {
    // Resume: the overlay is still alive (paused state) — re-injecting content.js
    // would rebuild it from scratch and wipe the existing transcript lines.
    await ensureOffscreen();
  } else {
    await recreateOffscreen();
    if (!usePanel) {
      let injected = true;
      try {
        await chrome.scripting.insertCSS({ target: { tabId }, files: ["content.css"] });
        await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
      } catch { injected = false; }
      // Page can't host the overlay (chrome://, blank, no tab) → fall back to the
      // dedicated subtitle window instead of failing.
      if (!injected) usePanel = true;
    }
  }
  active = {
    tabId, running: true,
    lang: lang || active.lang || "ko",
    langB: (resume ? active.langB : langBv) || active.langB || "vi",
    way: (resume ? active.way : wayv) || "one",
    source, panel: usePanel,
  };
  const showMsg = { from: "bg", type: "show", resume: !!resume, lang: active.lang, langB: active.langB, way: active.way };
  if (usePanel) {
    await openPanel();
    // New window: its content.js will re-request state via "panelReady". Existing
    // window (resume): this immediate send reaches it right away.
    chrome.runtime.sendMessage(showMsg).catch(() => {});
  } else {
    chrome.tabs.sendMessage(tabId, showMsg).catch(() => {});
  }

  // Tab audio only when the source uses it; "mic" (in-person) skips tab capture
  // so it works on any page without a meeting/video.
  let streamId = null;
  if (active.source !== "mic") {
    streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  }
  chrome.runtime.sendMessage({ target: "offscreen", type: "start", streamId, source: active.source, lang: active.lang, langB: active.langB, way: active.way, resume: !!resume });
}

function pauseCapture() {
  chrome.runtime.sendMessage({ target: "offscreen", type: "pause" });
  active.running = false;
}

function endCapture(summarize) {
  chrome.runtime.sendMessage({ target: "offscreen", type: "end", summarize: !!summarize });
  active.running = false;
}

// Returns a valid Supabase access token (refreshing if needed), or null.
// Lives in the service worker because the offscreen document lacks chrome.storage.
async function getAuthToken() {
  const s = await chrome.storage.local.get(["access_token", "refresh_token", "expires_at", "sb_url", "sb_key"]);
  if (!s.access_token) return null;
  const now = Math.floor(Date.now() / 1000);
  if (!s.expires_at || s.expires_at > now + 60) return s.access_token;
  if (s.refresh_token && s.sb_url && s.sb_key) {
    try {
      const r = await fetch(s.sb_url + "/auth/v1/token?grant_type=refresh_token", {
        method: "POST", headers: { "Content-Type": "application/json", apikey: s.sb_key },
        body: JSON.stringify({ refresh_token: s.refresh_token }),
      });
      const d = await r.json();
      if (r.ok && d.access_token) {
        await chrome.storage.local.set({ access_token: d.access_token, refresh_token: d.refresh_token, expires_at: now + (d.expires_in || 3600) });
        return d.access_token;
      }
    } catch {}
  }
  return s.access_token;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.cmd === "start") {
    startCapture(msg.lang, false, msg.source, msg.way, msg.langB, msg.tabId, msg.panel).then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.cmd === "panelReady") {
    // The subtitle window finished loading — (re)send it the current state.
    chrome.runtime.sendMessage({ from: "bg", type: "show", resume: false, lang: active.lang, langB: active.langB, way: active.way }).catch(() => {});
    chrome.runtime.sendMessage({ from: "bg", type: "status", text: active.running ? "LIVE" : "PAUSED" }).catch(() => {});
    sendResponse({ ok: true }); return;
  }
  if (msg.cmd === "resume") {
    startCapture(active.lang, true).then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.cmd === "pause") { pauseCapture(); sendResponse({ ok: true }); return; }
  if (msg.cmd === "end") { endCapture(msg.summarize); sendResponse({ ok: true }); return; }
  if (msg.cmd === "getState") { sendResponse(active); return; }
  if (msg.cmd === "setLang") { if (msg.lang) active.lang = msg.lang; if (msg.way) active.way = msg.way; if (msg.langB) active.langB = msg.langB; chrome.runtime.sendMessage({ target: "offscreen", type: "setLang", lang: active.lang, way: active.way, langB: active.langB }); sendResponse({ ok: true }); return; }
  if (msg.cmd === "openMicPerm") { chrome.tabs.create({ url: chrome.runtime.getURL("mic-permission.html") }); sendResponse({ ok: true }); return; }
  if (msg.cmd === "trUsage") {
    // Transcribe-only seconds → persistent daily counter. When the 60-min cap is
    // reached, pause the session (transcript kept so the user can still summarize).
    trAdd(msg.seconds || 0).then((over) => {
      if (over && active.running) {
        pauseCapture();
        const m = { from: "bg", type: "status", text: "⚠ Hết 60 phút Chỉ ghi hôm nay — bấm Tóm tắt để lưu lại." };
        if (active.tabId) chrome.tabs.sendMessage(active.tabId, m).catch(() => {});
        chrome.runtime.sendMessage(m).catch(() => {});
      }
    });
    sendResponse({ ok: true }); return;
  }
  if (msg.cmd === "authToken") { getAuthToken().then((t) => sendResponse(t)).catch(() => sendResponse(null)); return true; }

  // Relay results coming up from the offscreen document to the page overlay + popup.
  if (msg.from === "offscreen") {
    if (msg.type === "status" && (msg.text === "STOPPED" || msg.text === "PAUSED")) active.running = false;
    if (active.tabId) chrome.tabs.sendMessage(active.tabId, { ...msg, from: "bg" }).catch(() => {});
    chrome.runtime.sendMessage({ ...msg, from: "bg" }).catch(() => {});
  }
});
