// Injected into the meeting page: shows a draggable subtitle overlay and renders
// translation messages relayed from the background service worker.
(function () {
  // Replace any previous (possibly orphaned after an extension reload) instance.
  if (window.__ttCleanup) { try { window.__ttCleanup(); } catch (e) {} }
  const old = document.getElementById("tt-overlay");
  if (old) old.remove();

  const LANGS = [["ko", "🇰🇷 KO"], ["vi", "🇻🇳 VI"], ["en", "🇺🇸 EN"], ["ja", "🇯🇵 JA"], ["zh", "🇨🇳 ZH"], ["th", "🇹🇭 TH"], ["es", "🇪🇸 ES"], ["fr", "🇫🇷 FR"]];
  const LANG_OPTS = LANGS.map(([v, l]) => '<option value="' + v + '">' + l + "</option>").join("");
  const LOGO = chrome.runtime.getURL("icons/icon16.png");

  const box = document.createElement("div");
  box.id = "tt-overlay";
  box.innerHTML =
    '<div class="tt-head"><img class="tt-logo" src="' + LOGO + '" alt="">' +
    '<span class="tt-brand">TransFlash<span class="tt-sub"> · Live Translate</span></span>' +
    '<select class="tt-lang" id="tt-lang" title="Dịch sang">' + LANG_OPTS + "</select>" +
    '<span class="tt-langswap" id="tt-langswap" style="display:none">⇄</span>' +
    '<select class="tt-lang" id="tt-langB" style="display:none">' + LANG_OPTS + "</select>" +
    '<span class="tt-st" id="tt-st">준비 중…</span>' +
    '<span class="tt-acts">' +
    '<button class="tt-act pause" id="tt-pause">⏸ Dừng</button>' +
    '<button class="tt-act resume" id="tt-resume" style="display:none">▶ Tiếp tục</button>' +
    '<button class="tt-act" id="tt-psum" title="Tóm tắt tạm thời (tự cập nhật mỗi 15 phút)" style="display:none">📝</button>' +
    '<button class="tt-act" id="tt-copysc" title="Copy toàn bộ script đã ghi">📋 Script</button>' +
    '<button class="tt-act sum" id="tt-sumbtn">⏹ Tóm tắt</button>' +
    '<button class="tt-act" id="tt-close" style="display:none">× Đóng</button></span></div>' +
    '<div id="tt-micwarn" style="display:none"></div>' +
    '<div id="tt-lines"></div><div id="tt-sum" style="display:none"></div>' +
    '<div class="tt-grip" id="tt-grip" title="Kéo để chỉnh kích thước">' +
    '<svg width="14" height="14" viewBox="0 0 14 14"><g stroke="#cfe0ff" stroke-width="1.6" stroke-linecap="round">' +
    '<line x1="13" y1="2" x2="2" y2="13"/><line x1="13" y1="6.5" x2="6.5" y2="13"/><line x1="13" y1="11" x2="11" y2="13"/></g></svg></div>';
  document.documentElement.appendChild(box);

  const lines = box.querySelector("#tt-lines");
  const sumEl = box.querySelector("#tt-sum");
  const head = box.querySelector(".tt-head");
  const stEl = box.querySelector("#tt-st");
  const btnPause = box.querySelector("#tt-pause");
  const btnResume = box.querySelector("#tt-resume");
  const btnSum = box.querySelector("#tt-sumbtn");
  const btnPsum = box.querySelector("#tt-psum");
  const btnCopySc = box.querySelector("#tt-copysc");
  const btnClose = box.querySelector("#tt-close");
  const langSel = box.querySelector("#tt-lang");
  const langBSel = box.querySelector("#tt-langB");
  const langSwap = box.querySelector("#tt-langswap");
  const micWarnEl = box.querySelector("#tt-micwarn");
  let curWay = "one";
  [btnPause, btnResume, btnSum, btnPsum, btnCopySc, btnClose, langSel, langBSel].forEach((b) => b.addEventListener("mousedown", (e) => e.stopPropagation()));
  // Full running script (every finalized line), so "Copy script" grabs the whole
  // session — not just the ~7 lines currently visible in the overlay.
  let allLines = [];
  function scriptText() {
    return allLines.map((l) => {
      const who = l.spk != null ? "Speaker " + l.spk : "";
      let s = (who ? who + "\n" : "") + (l.o || "");
      if (l.t) s += "\n→ " + l.t;
      return s;
    }).join("\n\n");
  }
  btnCopySc.onclick = () => {
    const txt = scriptText();
    if (!txt) { btnCopySc.textContent = "— trống"; setTimeout(() => (btnCopySc.textContent = "📋 Script"), 1200); return; }
    navigator.clipboard.writeText(txt).then(() => {
      btnCopySc.textContent = "✓ Đã copy";
      setTimeout(() => (btnCopySc.textContent = "📋 Script"), 1400);
    }).catch(() => {});
  };
  // Latest auto-summary snapshot (updated every 15 min during long meetings).
  let partialData = null;
  btnPsum.onclick = () => showPartial();
  function showPartial() {
    if (!partialData) return;
    box.style.display = "flex"; lines.style.display = "none"; sumEl.style.display = "block";
    sumEl.innerHTML =
      '<div class="tt-sum-h">📝 Tóm tắt tạm thời<span class="tt-sum-act">' +
      '<button id="tt-pcopy">Copy tóm tắt</button><button id="tt-pdl">Tải tóm tắt</button>' +
      (partialData.transcript ? '<button id="tt-pcopytr">📋 Copy script</button><button id="tt-pdltr">Tải transcript</button>' : "") +
      '</span></div>' +
      '<div class="tt-sum-b">' + md(partialData.text) + "</div>" +
      '<div class="tt-sum-foot"><button id="tt-pback">← Quay lại phụ đề</button></div>';
    sumEl.querySelector("#tt-pcopy").onclick = () => navigator.clipboard.writeText(partialData.text);
    sumEl.querySelector("#tt-pdl").onclick = () => dlFile(partialData.text, "summary-partial.txt");
    const ctr = sumEl.querySelector("#tt-pcopytr");
    if (ctr) ctr.onclick = () => copyBtn(ctr, partialData.transcript, "📋 Copy script");
    const tr = sumEl.querySelector("#tt-pdltr");
    if (tr) tr.onclick = () => dlFile(partialData.transcript, "transcript.txt");
    sumEl.querySelector("#tt-pback").onclick = () => { sumEl.style.display = "none"; lines.style.display = "block"; };
  }
  function sendLang() { chrome.runtime.sendMessage({ cmd: "setLang", way: curWay, lang: langSel.value, langB: langBSel.value }); }
  langSel.onchange = sendLang;
  langBSel.onchange = sendLang;
  micWarnEl.style.cursor = "pointer";
  micWarnEl.onclick = () => chrome.runtime.sendMessage({ cmd: "openMicPerm" });
  function setMicWarn(text) {
    if (text) { micWarnEl.textContent = text + "   👉 Bấm vào đây để cấp quyền micro"; micWarnEl.style.display = "block"; }
    else micWarnEl.style.display = "none";
  }
  // m = "live" | "paused" | "stopped"
  // The header close button only appears while PAUSED (to abort a session). Once
  // stopped + summarized, closing happens from the summary panel footer instead —
  // keeping it away from the download buttons so it isn't tapped by accident.
  function setMode(m) {
    btnPause.style.display = m === "live" ? "" : "none";
    btnResume.style.display = m === "paused" ? "" : "none";
    btnSum.style.display = m === "stopped" ? "none" : "";
    btnCopySc.style.display = m === "stopped" ? "none" : "";
    btnClose.style.display = m === "paused" ? "" : "none";
    if (m !== "stopped") btnSum.textContent = "⏹ Tóm tắt";
  }
  // ended = the session is already finished (summary shown) — just hide the overlay.
  function doClose(ended) {
    if (!confirm("Đóng phụ đề?\nHãy tải Tóm tắt / Transcript trước nếu bạn muốn lưu lại.")) return;
    if (!ended) chrome.runtime.sendMessage({ cmd: "end", summarize: false });
    box.style.display = "none";
  }
  btnPause.onclick = () => { chrome.runtime.sendMessage({ cmd: "pause" }); setMode("paused"); setStatus("PAUSED"); };
  btnResume.onclick = () => { chrome.runtime.sendMessage({ cmd: "resume" }); setMode("live"); };
  btnSum.onclick = () => { chrome.runtime.sendMessage({ cmd: "end", summarize: true }); btnSum.textContent = "đang xử lý…"; };
  btnClose.onclick = () => doClose(false);

  function md(x) {
    return esc(x)
      .replace(/^#{1,3}\s*(.*)$/gm, '<b class="tt-h">$1</b>')
      .replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")
      .replace(/^[-*]\s+(.*)$/gm, "• $1")
      .replace(/\n/g, "<br>");
  }
  function showSummarizing() {
    box.style.display = "flex"; lines.style.display = "none"; sumEl.style.display = "block";
    sumEl.innerHTML = '<div class="tt-sum-h">📝 Đang tóm tắt…</div><div class="tt-sum-b" style="color:#9fb3d6">Vui lòng đợi vài giây.</div>';
  }
  function dlFile(content, name) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["﻿" + (content || "")], { type: "text/plain;charset=utf-8" }));
    a.download = name; a.click();
  }
  // Streaming summary: build the panel shell once (buttons live immediately —
  // the script/transcript is already available), then fill the body as tokens
  // stream in. Avoids rebuilding + re-binding handlers on every chunk.
  let curSummaryText = "", curTranscript = "";
  function showSummaryShell(transcript) {
    curSummaryText = ""; curTranscript = transcript || "";
    box.style.display = "flex"; lines.style.display = "none"; sumEl.style.display = "block";
    sumEl.innerHTML =
      '<div class="tt-sum-h">📝 Tóm tắt<span class="tt-sum-act">' +
      '<button id="tt-copy">Copy tóm tắt</button>' +
      '<button id="tt-dl">Tải tóm tắt</button>' +
      (curTranscript ? '<button id="tt-copytr">📋 Copy script</button><button id="tt-dltr">Tải transcript</button>' : "") +
      '</span></div>' +
      '<div class="tt-sum-b" id="tt-sumbody"><span style="color:#9fb3d6">✍️ Đang tóm tắt…</span></div>' +
      '<div class="tt-sum-foot"><button id="tt-sumclose">× Đóng phụ đề</button></div>';
    sumEl.querySelector("#tt-copy").onclick = () => navigator.clipboard.writeText(curSummaryText);
    sumEl.querySelector("#tt-dl").onclick = () => dlFile(curSummaryText, "summary.txt");
    const ctr = sumEl.querySelector("#tt-copytr"); if (ctr) ctr.onclick = () => copyBtn(ctr, curTranscript, "📋 Copy script");
    const tr = sumEl.querySelector("#tt-dltr"); if (tr) tr.onclick = () => dlFile(curTranscript, "transcript.txt");
    sumEl.querySelector("#tt-sumclose").onclick = () => doClose(true);
  }
  function updateSummaryBody(text) {
    curSummaryText = text || "";
    const b = box.querySelector("#tt-sumbody"); if (b) b.innerHTML = md(curSummaryText);
  }
  function finalizeSummary(text, transcript) {
    if (text) curSummaryText = text; if (transcript) curTranscript = transcript;
    const b = box.querySelector("#tt-sumbody"); if (b) b.innerHTML = md(curSummaryText || "—");
  }
  function copyBtn(btn, text, label) {
    navigator.clipboard.writeText(text || "").then(() => { btn.textContent = "✓ Đã copy"; setTimeout(() => (btn.textContent = label), 1400); }).catch(() => {});
  }
  function showSummary(text, transcript) {
    box.style.display = "flex"; lines.style.display = "none"; sumEl.style.display = "block";
    sumEl.innerHTML =
      '<div class="tt-sum-h">📝 Tóm tắt<span class="tt-sum-act">' +
      '<button id="tt-copy">Copy tóm tắt</button>' +
      '<button id="tt-dl">Tải tóm tắt</button>' +
      (transcript ? '<button id="tt-copytr">📋 Copy script</button><button id="tt-dltr">Tải transcript</button>' : "") +
      '</span></div>' +
      '<div class="tt-sum-b">' + md(text) + "</div>" +
      '<div class="tt-sum-foot"><button id="tt-sumclose">× Đóng phụ đề</button></div>';
    sumEl.querySelector("#tt-copy").onclick = () => navigator.clipboard.writeText(text);
    sumEl.querySelector("#tt-dl").onclick = () => dlFile(text, "summary.txt");
    const ctr = sumEl.querySelector("#tt-copytr");
    if (ctr) ctr.onclick = () => copyBtn(ctr, transcript, "📋 Copy script");
    const tr = sumEl.querySelector("#tt-dltr");
    if (tr) tr.onclick = () => dlFile(transcript, "transcript.txt");
    sumEl.querySelector("#tt-sumclose").onclick = () => doClose(true);
  }

  function setStatus(text) {
    if (text === "LIVE") { stEl.textContent = "● đang dịch"; stEl.className = "tt-st ok"; }
    else if (text === "PAUSED") { stEl.textContent = "⏸ tạm dừng"; stEl.className = "tt-st"; }
    else if (text === "STOPPED") { stEl.textContent = "đã dừng"; stEl.className = "tt-st"; }
    else { stEl.textContent = text; stEl.className = "tt-st err"; }
  }

  let cur = null;
  const esc = (s) => (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  function html(o, t, spk) {
    const name = spk != null ? '<div class="tt-spk" data-s="' + (((spk - 1) % 6 + 6) % 6) + '">Speaker ' + esc(String(spk)) + "</div>" : "";
    return name + '<div class="tt-o">' + esc(o) + '</div><div class="tt-t">' + esc(t) + "</div>";
  }
  function trim() { while (lines.children.length > 7) lines.removeChild(lines.firstChild); }

  function partial(o, t, spk) {
    if (!cur) { cur = document.createElement("div"); cur.className = "tt-line cur"; lines.appendChild(cur); }
    cur.innerHTML = html(o, t, spk); trim(); lines.scrollTop = lines.scrollHeight;
  }
  function final(o, t, spk) {
    if (o || t) allLines.push({ o, t, spk });
    if (!cur) { cur = document.createElement("div"); cur.className = "tt-line"; lines.appendChild(cur); }
    cur.className = "tt-line"; cur.innerHTML = html(o, t, spk); cur = null; trim(); lines.scrollTop = lines.scrollHeight;
  }

  function onBg(msg) {
    if (msg.from !== "bg") return;
    if (msg.type === "show") { box.style.display = "flex"; sumEl.style.display = "none"; lines.style.display = "block"; setMicWarn("");
      if (msg.way) curWay = msg.way; const two = curWay === "two", off = curWay === "off";
      langSel.style.display = off ? "none" : ""; langSwap.style.display = two ? "" : "none"; langBSel.style.display = two ? "" : "none";
      if (msg.lang) langSel.value = msg.lang; if (msg.langB) langBSel.value = msg.langB;
      if (!msg.resume) { lines.innerHTML = ""; cur = null; allLines = []; partialData = null; btnPsum.style.display = "none"; } setMode("live"); }
    else if (msg.type === "hide") box.style.display = "none";
    else if (msg.type === "status") { setStatus(msg.text); if (msg.text === "PAUSED") setMode("paused"); else if (msg.text === "STOPPED") setMode("stopped"); }
    else if (msg.type === "micWarn") setMicWarn(msg.text);
    else if (msg.type === "summarizing") { setMode("stopped"); showSummarizing(); }
    else if (msg.type === "summaryStart") { setMode("stopped"); showSummaryShell(msg.transcript); }
    else if (msg.type === "summaryChunk") { updateSummaryBody(msg.text); }
    else if (msg.type === "summaryDone") { finalizeSummary(msg.text, msg.transcript); }
    else if (msg.type === "summary") { setMode("stopped"); showSummary(msg.text, msg.transcript); }
    else if (msg.type === "partialSummary") { partialData = { text: msg.text, transcript: msg.transcript }; btnPsum.style.display = ""; btnPsum.textContent = "📝 Tóm tắt"; }
    else if (msg.type === "partial") partial(msg.orig, msg.trans, msg.spk);
    else if (msg.type === "final") final(msg.orig, msg.trans, msg.spk);
  }
  chrome.runtime.onMessage.addListener(onBg);

  // drag (header) + resize (corner grip)
  const grip = box.querySelector("#tt-grip");
  let dx = 0, dy = 0, dragging = false;
  let rz = false, rx = 0, ry = 0, rw = 0, rh = 0;
  function detach() {
    const r = box.getBoundingClientRect();
    box.style.transform = "none"; box.style.left = r.left + "px"; box.style.top = r.top + "px"; box.style.bottom = "auto";
    return r;
  }
  function onHeadDown(e) { dragging = true; const r = detach(); dx = e.clientX - r.left; dy = e.clientY - r.top; e.preventDefault(); }
  function onGripDown(e) { rz = true; const r = detach(); rx = e.clientX; ry = e.clientY; rw = r.width; rh = r.height; e.preventDefault(); e.stopPropagation(); }
  function onMove(e) {
    if (rz) {
      const w = Math.min(Math.max(rw + (e.clientX - rx), 300), window.innerWidth * 0.96);
      const h = Math.min(Math.max(rh + (e.clientY - ry), 130), window.innerHeight * 0.88);
      box.style.width = w + "px"; box.style.height = h + "px";
    } else if (dragging) {
      box.style.left = (e.clientX - dx) + "px"; box.style.top = (e.clientY - dy) + "px";
    }
  }
  function onUp() { dragging = false; rz = false; }
  head.addEventListener("mousedown", onHeadDown);
  grip.addEventListener("mousedown", onGripDown);
  window.addEventListener("mousemove", onMove);
  window.addEventListener("mouseup", onUp);

  window.__ttCleanup = function () {
    try { box.remove(); } catch (e) {}
    try { chrome.runtime.onMessage.removeListener(onBg); } catch (e) {}
    try { window.removeEventListener("mousemove", onMove); } catch (e) {}
    try { window.removeEventListener("mouseup", onUp); } catch (e) {}
  };
})();
